//define the class with the field that each review will have
export class Review{
    name!: string;
    email!: string;
    rating!: number;
    description!:string;
  }